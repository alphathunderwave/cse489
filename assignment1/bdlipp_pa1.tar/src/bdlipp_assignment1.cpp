/**
 * @bdlipp_assignment1
 * @author  Benjamin Lipp <bdlipp@buffalo.edu>
 * @version 1.0
 *
 * @section LICENSE
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details at
 * http://www.gnu.org/copyleft/gpl.html
 *
 * @section DESCRIPTION
 *
 * This contains the main function. Add further description here....
 */
#include <iostream>
#include <stdio.h>
#include <string.h>

#include "../include/global.h"
#include "../include/logger.h"
char input[1024];
char IP[256];
char ListenPORT[1024];

using namespace std;

int start_client(char *port){
	strcpy(ListenPORT,port);
	cin >> input;
	while(strcmp(input,(char *)"EXIT")!=0){
		if(strcmp(input,(char *)"AUTHOR")==0){
			cse4589_print_and_log((char *)"[%s:SUCCESS]\n", "AUTHOR");
			cse4589_print_and_log("I, %s, have read and understood the course academic integrity policy.\n", "bdlipp");
			cse4589_print_and_log((char *)"[%s:END]\n", "AUTHOR");
		}
		else if(strcmp(input,(char *)"IP")==0){
			cse4589_print_and_log((char *)"[%s:SUCCESS]\n", "IP");
			cse4589_print_and_log("IP:%s\n", IP);
			cse4589_print_and_log((char *)"[%s:END]\n", "IP");

		}
		else if(strcmp(input,(char *)"PORT")==0){
			cse4589_print_and_log((char *)"[%s:SUCCESS]\n", "PORT");
			cse4589_print_and_log("PORT:%s\n", ListenPORT);
			cse4589_print_and_log((char *)"[%s:END]\n", "PORT");

		}


		cin >> input;

	}
	return 0;
}

int start_server(char *port){
	strcpy(ListenPORT,port);
	cin >> input;
	while(strcmp(input,(char *)"EXIT")!=0){
		if(strcmp(input,(char *)"AUTHOR")==0){
			cse4589_print_and_log((char *)"[%s:SUCCESS]\n", "AUTHOR");
			cse4589_print_and_log("I, %s, have read and understood the course academic integrity policy.\n", "bdlipp");
			cse4589_print_and_log((char *)"[%s:END]\n", "AUTHOR");
		}
		else if(strcmp(input,(char *)"IP")){
			cse4589_print_and_log((char *)"[%s:SUCCESS]\n", "IP");
			cse4589_print_and_log("IP:%s\n", IP);
			cse4589_print_and_log((char *)"[%s:END]\n", "IP");

		}
		else if(strcmp(input,(char *)"PORT")){
			cse4589_print_and_log((char *)"[%s:SUCCESS]\n", "PORT");
			cse4589_print_and_log("PORT:%s\n", ListenPORT);
			cse4589_print_and_log((char *)"[%s:END]\n", "PORT");

		}

		cin >> input;

	}

	return 0;
}

/**
 * main function
 *
 * @param  argc Number of arguments
 * @param  argv The argument list
 * @return 0 EXIT_SUCCESS
 */
int main(int argc, char **argv)
{
	/*Init. Logger*/
	cse4589_init_log(argv[2]);

	/* Clear LOGFILE*/
    fclose(fopen(LOGFILE, "w"));
	if(argc != 3){
		cse4589_print_and_log("no\n");
		return 1;
	}
	/*Start Here*/
	std::string port = argv[2];
	int a;
	if(*argv[1]=='c'){
		a=start_client(argv[2]);
	}
	else if(*argv[1]=='s'){
		a=start_server(argv[2]);
	}
	else{
		cse4589_print_and_log("no\n");
		return 1;
	}
	cse4589_print_and_log("port %s \n%i\n",port.c_str(),a);
	return 0;
}
